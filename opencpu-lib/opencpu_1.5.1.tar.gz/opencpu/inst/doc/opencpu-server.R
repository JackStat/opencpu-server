## ----eval=FALSE----------------------------------------------------------
#  library(devtools)
#  install_github("gitstats", "opencpu")

## ----eval=FALSE----------------------------------------------------------
#  install.packages("opencpu")

## ----eval=FALSE----------------------------------------------------------
#  library(opencpu)

## ----eval=FALSE----------------------------------------------------------
#  install_github("gitstats", "opencpu")
#  opencpu$browse("library/gitstats/www")

## ----eval=FALSE----------------------------------------------------------
#  install.packages("ggplot2")
#  install.packages("glmnet")
#  
#  library(devtools)
#  install_github("dplyr", "hadley")

